package modelo;

import exceptions.InvalidDateFormatException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Diego Ortega
 */
public class ClienteTest {
    
    //Atributos para la prueba.
    
    /*
    public Cliente(String nombre, String rfc, String domicilio, String telefono, String zona)
    */
    private Cliente pruebaCliente = new Cliente("Nacho Varga", "1234567890", 
            "Mishnory Commensality", "5538779463", "Nogales", "04/02/2024", 111);
    
    
    
    public ClienteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getFechaPrimeraCompra method, of class Cliente.
     */
    
    @Test
    public void testGetFechaPrimeraCompra() {
        
        System.out.println("Prueba de getFechaPrimeraCompra");
        assertEquals("04/02/2024", pruebaCliente.getFechaPrimeraCompra());
        
        
    }
    
    
    /**
     * Test of getIdCliente method, of class Cliente.
     */
    @Test
    public void testGetIdCliente() {
        System.out.println("Prueba de getIdCliente");
        assertEquals(111, pruebaCliente.getIdCliente());
        
    }
    
    
    
    /**
     * Test of setFechaPrimeraCompra method, of class Cliente.
     */
    
    @Test(expected = InvalidDateFormatException.class)
    public void testSetFechaPrimeraCompra() throws InvalidDateFormatException {
        System.out.println("Prueba de setFechaPrimeraCompra");
        pruebaCliente.setFechaPrimeraCompra("aaa");
    }
    
    
    /**
     * Test of setIdCliente method, of class Cliente.
     */
    @Test
    public void testSetIdCliente() {
        System.out.println("Prueba de setIdCliente");
        pruebaCliente.setIdCliente(111);
        assertEquals(111, pruebaCliente.getIdCliente());
    }

    /**
     * Test of crearCliente method, of class Cliente.
     */
    
    /*
    @Test
    public void testCrearCliente() {
        System.out.println("crearCliente");
        Cliente expResult = null;
        Cliente result = Cliente.crearCliente();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    */
    
}
