package exceptions;

/**
 *
 * @author Diego Ortega
 * @desc Clase que contiene excepciones para ID no encontrado.
 */
public class IDNotFoundException extends Exception{
    
    public IDNotFoundException(){
        
        super("Error: ID no encontrado.");
        
    }
    
    public IDNotFoundException(String msj){
        
        super(msj);
        
    }
    
}
