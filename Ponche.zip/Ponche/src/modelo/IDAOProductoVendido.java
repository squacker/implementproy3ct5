package modelo;

public interface IDAOProductoVendido {
    
    public boolean insertarProductoVendido(ProductoVendido producto);
  
    public boolean borrarProductoVendido(int idProducto);
    
    
    
}
