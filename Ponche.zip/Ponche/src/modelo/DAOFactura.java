package modelo;

import java.util.HashMap;
import java.util.Map;

public class DAOFactura implements IDAOFactura {

    @Override
    public boolean insertarFactura(Factura factura) {

    }

    @Override
    public Factura obtenerFactura(int numeroFactura) {

    }

    @Override
    public boolean eliminarFactura(int numeroFactura) {

    }

    @Override
    public boolean actualizarFactura(Factura factura) {

        }
        return false;
    }
}
